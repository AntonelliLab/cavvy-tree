
# Cavvy-tree

Results for *cavvy-tree* project: "construction of phylogenetic supermatrix"
for select Caviomorph families.

Three supermatrices are made available for different strictnesses of
supermatrix-completeness. "low" provides the matrix with maximum species
coverage, but lots of gaps. "high" provides minimum number of gaps but has
fewest number of species.

Matrices are provided in FASTA and PHYLIP format.

phylotaR results are summarised in "clusters_summary" and "species_summary".

For each matrix type a RAxML guide tree and best partition schemes according to
PartitionFinder2 are provided.

For more information visit: https://github.com/AntonelliLab/cavvy-tree

## Folder structure

```
results/
- clusters_summary.csv
- species_summary.csv
- - low/
- - - RAxML_bestTree
- - - supermatrix.fasta
- - - supermatrix.phy
- - - best_scheme.txt
- - mid/
- - - RAxML_bestTree
- - - supermatrix.fasta
- - - supermatrix.phy
- - - best_scheme.txt
- - high/
- - - RAxML_bestTree
- - - supermatrix.fasta
- - - supermatrix.phy
- - - best_scheme.txt
- README.txt
```


**Date and time**: 
2019-10-09 16:08:15